﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IsATree
{
    public class CheckTree
    {
        //===============================================================================
        //Your Code is Here:
        /// <summary>
        /// Develop an efficient algorithm to determine whether the given graph is a tree or not
        /// </summary>
        /// <param name="vertices">The vertices array (1 ≤ size ≤ 1000) of the given graph </param>
        /// <param name="edges">The edges of the given graph as a list of KeyValuePair</param>
        /// <returns>If Contains: return true if tree, else, return false</returns>
        public static bool IsTree(string[] vertices, List<KeyValuePair<string, string>> edges)
        {
            throw new NotImplementedException();
        }
        //===============================================================================
    }
}
